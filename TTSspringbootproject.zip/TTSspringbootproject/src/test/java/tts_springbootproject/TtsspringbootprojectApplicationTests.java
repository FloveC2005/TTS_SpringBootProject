package tts_springbootproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TtsspringbootprojectApplicationTests {

    @Test
    void contextLoads() {
    }

}
