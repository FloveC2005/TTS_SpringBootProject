package tts_springbootproject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tts_springbootproject.model.ttssb;
import tts_springbootproject.repository.ttssbRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
@RequestMapping("/api")
public class ttssbCoontroller {

    @Autowired
    ttssbRepository coffeeRepository;

    @GetMapping("/coffees")
    public ResponseEntity<List<ttssb>> getAllCoffees(@RequestParam(required = false) String coffeeName){
        try{
            List<ttssb> coffeesList = new ArrayList<ttssb>();

            if(coffeeName == null)
                coffeeRepository.findAll().forEach(coffeesList::add);
            else
                coffeeRepository.findByCoffeeName(coffeeName).forEach(coffeesList::add);

            if(coffeesList.isEmpty()){
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(coffeesList, HttpStatus.OK);
        }catch (Exception e){
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/coffees/{id}")
    public ResponseEntity<ttssb> getCoffeeById(@PathVariable("id") long id){
        Optional<ttssb> coffeeDta = coffeeRepository.findById(id);

        if(coffeeDta.isPresent()){
            return new ResponseEntity<>(coffeeDta.get(), HttpStatus.OK);
        }else{
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/coffees")
    public ResponseEntity<ttssb> createCoffee(@RequestBody ttssb coffee){
        try{
            ttssb _coffee = coffeeRepository.save(new ttssb(coffee.getCoffee_name(), coffee.getCoffee_description(),
                    coffee.getSize(), false));
            return new ResponseEntity<>(_coffee, HttpStatus.CREATED);
        }catch (Exception ex){
            return new ResponseEntity<>(null, HttpStatus.EXPECTATION_FAILED);
        }
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<ttssb> updateCoffee(@PathVariable("id") long id, @RequestBody ttssb coffee){
        Optional<ttssb> coffeeDta = coffeeRepository.findById(id);

        if(coffeeDta.isPresent()){
            ttssb _coffee = coffeeDta.get();
            _coffee.setCoffee_name(coffee.getCoffee_name());
            _coffee.setCoffee_description(coffee.getCoffee_description());
            _coffee.setSize(coffee.getSize());
            _coffee.setFoam(coffee.isFoam());
            return new ResponseEntity<>(coffeeRepository.save(_coffee), HttpStatus.OK);
        }else{
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/coffees/{id}")
    public ResponseEntity<HttpStatus> deleteCoffee(@PathVariable("id") long id){
        try{
            coffeeRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }catch (Exception ex){
            return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
        }
    }

    @DeleteMapping("/coffees")
    public ResponseEntity<HttpStatus> deleteAllCoffees(){
        try{
            coffeeRepository.deleteAll();
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }catch (Exception ex){
            return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
        }
    }

    @GetMapping("/coffees/Foam")
    public ResponseEntity<List<ttssb>> findByFoam(){
        try{
            List<ttssb> coffees = coffeeRepository.findByFoam(true);

            if(coffees.isEmpty()){
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<>(coffees, HttpStatus.OK);
        }catch (Exception e){
            return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
        }
    }

}
