package tts_springbootproject.model;


import javax.persistence.*;

@Entity
//@Table(name = "coffees")
public class ttssb {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    //@Column(name = "coffee_name")
    private String coffee_name;

    //@Column(name = "coffee_description")
    private  String coffee_description;

    //@Column(name = "size")
    private String size;

    //@Column(name = "isFoam")
    private boolean isFoam;

    public ttssb(){

    }

    public ttssb(String coffee_name, String coffee_description, String size, boolean isFoam) {
        this.coffee_name = coffee_name;
        this.coffee_description = coffee_description;
        this.size = size;
        this.isFoam = isFoam;
    }

    public long getId() {
        return id;
    }

    public String getCoffee_name() {

        return coffee_name;
    }

    public void setCoffee_name(String coffee_name) {

        this.coffee_name = coffee_name;
    }

    public String getCoffee_description() {

        return coffee_description;
    }

    public void setCoffee_description(String coffee_description) {

        this.coffee_description = coffee_description;
    }

    public String getSize() {

        return size;
    }

    public void setSize(String size) {

        this.size = size;
    }

    public boolean isFoam() {

        return isFoam;
    }

    public void setFoam(boolean foam) {

        isFoam = foam;
    }

    @Override
    public String toString() {
        return "ttssb{" +
                "id=" + id +
                ", coffee_name='" + coffee_name + '\'' +
                ", coffee_description='" + coffee_description + '\'' +
                ", size='" + size + '\'' +
                ", isFoam=" + isFoam +
                '}';
    }
}
