package tts_springbootproject.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import tts_springbootproject.model.ttssb;

import java.util.List;

public interface ttssbRepository extends JpaRepository<ttssb, Long> {

    List<ttssb> findByFoam(boolean isFoam);
    List<ttssb>findByCoffeeName(String coffee_name);

}
